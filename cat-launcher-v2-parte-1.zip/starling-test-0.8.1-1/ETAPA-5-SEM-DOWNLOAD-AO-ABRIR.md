# ETAPA 5 - sem tela de download ao abrir - NÃO COMPILADO

Sem cargo/NDK neste ambiente: nada foi compilado ou testado.

- setup/mod.rs: removido o início automático (auto_started): não cria perfil nem baixa ao abrir.
  Nova ação Play na tela inicial (Step::Start): só ela (ou entrar com conta) libera o download dos
  arquivos do jogo. Conta já logada não baixa sozinha (campo `play`).
- update_offer.rs: AUTO_UPDATE_CHECK = false: sem verificação/download de atualização do app.
- Mantido: jogo, mundos, mods, skins, conta offline, Tailscale e o preparo dos arquivos após o Play.
